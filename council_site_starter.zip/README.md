
# 議員活動レポート（超シンプル版）

**更新は `data.json` を1ファイル編集するだけ。** GitHub Pages や Netlify にそのまま置けば動きます（ビルド不要）。

## 使い方（3分）
1. このフォルダの中身をまるごとアップロード（例：GitHub → New repository → Upload files）。  
2. `Settings → Pages` から公開（GitHub Pages など）。  
3. 以後の更新は `data.json` をウェブ上で開いて編集→「Commit」で即反映。

## 構成
- `index.html` … 本体（1ページ）  
- `styles.css` … スタイル  
- `script.js` … 描画＆検索&フィルタ  
- `data.json` … **ここだけ編集**（公約・活動・お知らせ）  
- `favicon.svg` … アイコン

## `data.json` の書き方（要点）
```json
{
  "site": {
    "title": "サイト名",
    "subtitle": "サブタイトル",
    "updated_at": "2025-10-03 11:00",
    "links": [{"label":"X","href":"https://x.com/"}]
  },
  "manifesto": [
    {
      "title":"公約タイトル",
      "status":"done | partial | wip | none",
      "department":"所管",
      "period":"期間",
      "tags":["タグ1","タグ2"],
      "body":"詳細",
      "links":[{"label":"根拠資料","href":"https://..."}]
    }
  ],
  "activities":[
    {
      "title":"活動タイトル",
      "date":"YYYY-MM-DD",
      "location":"場所",
      "tags":["タグ"],
      "body":"詳細",
      "links":[{"label":"議事録","href":"https://..."}],
      "media":["https://...jpg"]
    }
  ],
  "news":[{"title":"お知らせ","date":"YYYY-MM-DD","body":"本文"}]
}
```

### ステータス表示
- `done` = 達成（緑） / 100%
- `partial` = 一部達成（黄） / 60%
- `wip` = 進行中（黄） / 35%
- `none` = 未着手（灰） / 0%

## ワンクリック確認
各項目は `<details>` を採用し、「内容を開く」を**ワンクリックで展開**できます。

## 小ワザ
- 証跡URL（外部の議事録・PDF・X投稿など）を `links` に入れると自動で表示
- キーワード検索（公約/活動）・ステータスフィルタ（公約）に対応
- 1ファイル更新のため、**スマホからでも GitHub の画面で編集→保存だけ**

## カスタマイズ（任意）
- `styles.css` の `--brand` を変更でテーマカラーを即変更
- セクション名を変える場合は `index.html` のボタン名を編集

---
