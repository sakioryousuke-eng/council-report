/* app.js */
async function loadData(){ const r=await fetch('./data/data.json'); if(!r.ok) throw new Error('data.json load failed'); return await r.json(); }
function el(t,a={},...c){const n=document.createElement(t); for(const[k,v]of Object.entries(a)){ if(k==='class') n.className=v; else if(k.startsWith('on')) n.addEventListener(k.slice(2),v); else n.setAttribute(k,v);} c.flat().forEach(x=>{ if(x==null) return; n.appendChild(typeof x==='string'?document.createTextNode(x):x);}); return n;}
function renderPledges(root,d){ const list=el('div',{class:'cards'}); const pill=k=>({starting_rollout:'pill pill-starting',accelerating:'pill pill-accel',in_progress:'pill pill-prog',in_discussion:'pill pill-discuss',under_review:'pill pill-review',completed:'pill pill-done'})[k]||'pill';
 (d.pledges||[]).forEach(p=>{ const ev=el('ul',{class:'evidence'},...(p.evidence||[]).map(e=>el('li',{},`${e.source}: ${e.note||e.summary||''}`)));
  const rel=el('ul',{class:'related'},...(p.related_councillors||[]).map(r=>el('li',{},`${r.date} ${r.name}: ${r.topic}`)));
  list.appendChild(el('article',{class:'card'},
    el('h3',{},p.title),
    el('div',{class:'meta'}, el('span',{class:pill(p.status)},p.status), p.last_updated?el('span',{class:'updated'},`更新: ${p.last_updated}`):null),
    el('p',{class:'desc'},p.description||''),
    ev.childNodes.length?el('details',{},el('summary',{},'証拠（一次資料ベース）'),ev):null,
    rel.childNodes.length?el('details',{},el('summary',{},'関連する他議員の一般質問'),rel):null
  ));});
 root.replaceChildren(list);}
function renderMatrix(root,d){ const tbl=el('table',{class:'matrix'}), thead=el('thead',{},el('tr',{},el('th',{},'テーマ'),el('th',{},'崎尾（一般質問表＋議事録）'),el('th',{},'関連する他議員'))), tbody=el('tbody',{});
 (d.matrix||[]).forEach(r=>{ const s=el('ul',{},...(r.sakio||[]).map(x=>el('li',{},`${x.date}：${(x.items||[]).join('・')}${x.minutes_note?`（補足：${x.minutes_note}）`:''}`)));
  const o=el('ul',{},...(r.related_councillors||[]).map(y=>el('li',{},`${y.date} ${y.name}：${y.topic}`)));
  tbody.appendChild(el('tr',{},el('td',{},r.theme),el('td',{},s),el('td',{},o)));});
 tbl.appendChild(thead); tbl.appendChild(tbody); root.replaceChildren(tbl);}
function renderSources(root,d){ const list=el('ul',{},...(d.meta?.scope?.pdf_general_question_tables||[]).map(n=>el('li',{},`PDF: ${n}`)), ...(d.meta?.scope?.word_minutes_sakio||[]).map(n=>el('li',{},`Word: ${n}`))); root.replaceChildren(list);}
async function main(){ const data=await loadData(); const tabs=document.querySelectorAll('[data-tab]'); const views={matrix:document.getElementById('view-matrix'), pledges:document.getElementById('view-pledges'), sources:document.getElementById('view-sources')};
 function activate(tab){ tabs.forEach(t=>t.classList.toggle('active', t.dataset.tab===tab)); Object.entries(views).forEach(([k,v])=>v.style.display=(k===tab?'block':'none')); if(tab==='matrix') renderMatrix(views.matrix,data); if(tab==='pledges') renderPledges(views.pledges,data); if(tab==='sources') renderSources(views.sources,data);}
 tabs.forEach(t=>t.addEventListener('click',()=>activate(t.dataset.tab))); activate('matrix'); }
main().catch(e=>{ const r=document.getElementById('view-matrix'); if(r) r.textContent='Error: '+e.message; console.error(e); });
